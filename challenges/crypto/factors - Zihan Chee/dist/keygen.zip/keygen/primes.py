from random import randrange, getrandbits
from math import gcd

def is_prime(n, k=128):
    """ Test if a number is prime
        Args:
            n -- int -- the number to test
            k -- int -- the number of tests to do
        return True if n is prime
    """
    # Test if n is not even.
    # But care, 2 is prime !
    if n == 2 or n == 3:
        return True
    if n <= 1 or n % 2 == 0:
        return False
    # find r and s
    s = 0
    r = n - 1
    while r & 1 == 0:
        s += 1
        r //= 2
    # do k tests
    for _ in range(k):
        a = randrange(2, n - 1)
        x = pow(a, r, n)
        if x != 1 and x != n - 1:
            j = 1
            while j < s and x != n - 1:
                x = pow(x, 2, n)
                if x == 1:
                    return False
                j += 1
            if x != n - 1:
                return False
    return True
def generate_prime_candidate(length):
    a = 0b1 << (length-1) 
    p = randrange(
            a,
            a + 1180591620717411303425
        )
    # apply a mask to set MSB and LSB to 1
    p |= (1 << length - 1) | 1
    return p
def generate_prime_number(length=2048):
    """ Generate a prime
        Args:
            length -- int -- length of the prime to generate, in bits
        return a prime
    """
    p = 4
    # keep generating while the primality test fail
    while not is_prime(p, 128):
        p = generate_prime_candidate(length)
    return p



def generate_e_and_d(phi, lower_bound=2):
    e = randrange(lower_bound, phi)
    g = gcd(e, phi)

    while True:

        e = randrange(lower_bound, phi)
        g = gcd(e, phi)
        # Generate d, which is kept private
        try:
            d = pow(e, -1, phi)
        except ValueError:
            continue
        if g == 1 and e != d:
            break
    return (e, d)
