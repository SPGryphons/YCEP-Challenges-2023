from primes import generate_prime_number, generate_e_and_d
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPublicNumbers
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives import serialization

p = generate_prime_number(2048)
q = generate_prime_number(2048)


n = p * q
phi = (p-1) * (q-1)
e, d = generate_e_and_d(phi)

pubkey = RSAPublicNumbers(e, n).public_key()

with open("pubkey.pem", "wb") as f:
    f.write(pubkey.public_bytes(
       encoding=serialization.Encoding.PEM,
       format=serialization.PublicFormat.SubjectPublicKeyInfo))